var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/react/cjs/react.production.min.js
var require_react_production_min = __commonJS({
  "node_modules/react/cjs/react.production.min.js"(exports) {
    "use strict";
    var l = Symbol.for("react.element");
    var n = Symbol.for("react.portal");
    var p = Symbol.for("react.fragment");
    var q = Symbol.for("react.strict_mode");
    var r = Symbol.for("react.profiler");
    var t = Symbol.for("react.provider");
    var u = Symbol.for("react.context");
    var v = Symbol.for("react.forward_ref");
    var w = Symbol.for("react.suspense");
    var x = Symbol.for("react.memo");
    var y = Symbol.for("react.lazy");
    var z = Symbol.iterator;
    function A(a) {
      if (null === a || "object" !== typeof a) return null;
      a = z && a[z] || a["@@iterator"];
      return "function" === typeof a ? a : null;
    }
    var B = { isMounted: function() {
      return false;
    }, enqueueForceUpdate: function() {
    }, enqueueReplaceState: function() {
    }, enqueueSetState: function() {
    } };
    var C = Object.assign;
    var D = {};
    function E(a, b, e) {
      this.props = a;
      this.context = b;
      this.refs = D;
      this.updater = e || B;
    }
    E.prototype.isReactComponent = {};
    E.prototype.setState = function(a, b) {
      if ("object" !== typeof a && "function" !== typeof a && null != a) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, a, b, "setState");
    };
    E.prototype.forceUpdate = function(a) {
      this.updater.enqueueForceUpdate(this, a, "forceUpdate");
    };
    function F() {
    }
    F.prototype = E.prototype;
    function G(a, b, e) {
      this.props = a;
      this.context = b;
      this.refs = D;
      this.updater = e || B;
    }
    var H = G.prototype = new F();
    H.constructor = G;
    C(H, E.prototype);
    H.isPureReactComponent = true;
    var I = Array.isArray;
    var J = Object.prototype.hasOwnProperty;
    var K = { current: null };
    var L = { key: true, ref: true, __self: true, __source: true };
    function M(a, b, e) {
      var d, c = {}, k = null, h = null;
      if (null != b) for (d in void 0 !== b.ref && (h = b.ref), void 0 !== b.key && (k = "" + b.key), b) J.call(b, d) && !L.hasOwnProperty(d) && (c[d] = b[d]);
      var g = arguments.length - 2;
      if (1 === g) c.children = e;
      else if (1 < g) {
        for (var f = Array(g), m = 0; m < g; m++) f[m] = arguments[m + 2];
        c.children = f;
      }
      if (a && a.defaultProps) for (d in g = a.defaultProps, g) void 0 === c[d] && (c[d] = g[d]);
      return { $$typeof: l, type: a, key: k, ref: h, props: c, _owner: K.current };
    }
    function N(a, b) {
      return { $$typeof: l, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner };
    }
    function O(a) {
      return "object" === typeof a && null !== a && a.$$typeof === l;
    }
    function escape(a) {
      var b = { "=": "=0", ":": "=2" };
      return "$" + a.replace(/[=:]/g, function(a2) {
        return b[a2];
      });
    }
    var P = /\/+/g;
    function Q(a, b) {
      return "object" === typeof a && null !== a && null != a.key ? escape("" + a.key) : b.toString(36);
    }
    function R(a, b, e, d, c) {
      var k = typeof a;
      if ("undefined" === k || "boolean" === k) a = null;
      var h = false;
      if (null === a) h = true;
      else switch (k) {
        case "string":
        case "number":
          h = true;
          break;
        case "object":
          switch (a.$$typeof) {
            case l:
            case n:
              h = true;
          }
      }
      if (h) return h = a, c = c(h), a = "" === d ? "." + Q(h, 0) : d, I(c) ? (e = "", null != a && (e = a.replace(P, "$&/") + "/"), R(c, b, e, "", function(a2) {
        return a2;
      })) : null != c && (O(c) && (c = N(c, e + (!c.key || h && h.key === c.key ? "" : ("" + c.key).replace(P, "$&/") + "/") + a)), b.push(c)), 1;
      h = 0;
      d = "" === d ? "." : d + ":";
      if (I(a)) for (var g = 0; g < a.length; g++) {
        k = a[g];
        var f = d + Q(k, g);
        h += R(k, b, e, f, c);
      }
      else if (f = A(a), "function" === typeof f) for (a = f.call(a), g = 0; !(k = a.next()).done; ) k = k.value, f = d + Q(k, g++), h += R(k, b, e, f, c);
      else if ("object" === k) throw b = String(a), Error("Objects are not valid as a React child (found: " + ("[object Object]" === b ? "object with keys {" + Object.keys(a).join(", ") + "}" : b) + "). If you meant to render a collection of children, use an array instead.");
      return h;
    }
    function S(a, b, e) {
      if (null == a) return a;
      var d = [], c = 0;
      R(a, d, "", "", function(a2) {
        return b.call(e, a2, c++);
      });
      return d;
    }
    function T(a) {
      if (-1 === a._status) {
        var b = a._result;
        b = b();
        b.then(function(b2) {
          if (0 === a._status || -1 === a._status) a._status = 1, a._result = b2;
        }, function(b2) {
          if (0 === a._status || -1 === a._status) a._status = 2, a._result = b2;
        });
        -1 === a._status && (a._status = 0, a._result = b);
      }
      if (1 === a._status) return a._result.default;
      throw a._result;
    }
    var U = { current: null };
    var V = { transition: null };
    var W = { ReactCurrentDispatcher: U, ReactCurrentBatchConfig: V, ReactCurrentOwner: K };
    function X() {
      throw Error("act(...) is not supported in production builds of React.");
    }
    exports.Children = { map: S, forEach: function(a, b, e) {
      S(a, function() {
        b.apply(this, arguments);
      }, e);
    }, count: function(a) {
      var b = 0;
      S(a, function() {
        b++;
      });
      return b;
    }, toArray: function(a) {
      return S(a, function(a2) {
        return a2;
      }) || [];
    }, only: function(a) {
      if (!O(a)) throw Error("React.Children.only expected to receive a single React element child.");
      return a;
    } };
    exports.Component = E;
    exports.Fragment = p;
    exports.Profiler = r;
    exports.PureComponent = G;
    exports.StrictMode = q;
    exports.Suspense = w;
    exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W;
    exports.act = X;
    exports.cloneElement = function(a, b, e) {
      if (null === a || void 0 === a) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
      var d = C({}, a.props), c = a.key, k = a.ref, h = a._owner;
      if (null != b) {
        void 0 !== b.ref && (k = b.ref, h = K.current);
        void 0 !== b.key && (c = "" + b.key);
        if (a.type && a.type.defaultProps) var g = a.type.defaultProps;
        for (f in b) J.call(b, f) && !L.hasOwnProperty(f) && (d[f] = void 0 === b[f] && void 0 !== g ? g[f] : b[f]);
      }
      var f = arguments.length - 2;
      if (1 === f) d.children = e;
      else if (1 < f) {
        g = Array(f);
        for (var m = 0; m < f; m++) g[m] = arguments[m + 2];
        d.children = g;
      }
      return { $$typeof: l, type: a.type, key: c, ref: k, props: d, _owner: h };
    };
    exports.createContext = function(a) {
      a = { $$typeof: u, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null };
      a.Provider = { $$typeof: t, _context: a };
      return a.Consumer = a;
    };
    exports.createElement = M;
    exports.createFactory = function(a) {
      var b = M.bind(null, a);
      b.type = a;
      return b;
    };
    exports.createRef = function() {
      return { current: null };
    };
    exports.forwardRef = function(a) {
      return { $$typeof: v, render: a };
    };
    exports.isValidElement = O;
    exports.lazy = function(a) {
      return { $$typeof: y, _payload: { _status: -1, _result: a }, _init: T };
    };
    exports.memo = function(a, b) {
      return { $$typeof: x, type: a, compare: void 0 === b ? null : b };
    };
    exports.startTransition = function(a) {
      var b = V.transition;
      V.transition = {};
      try {
        a();
      } finally {
        V.transition = b;
      }
    };
    exports.unstable_act = X;
    exports.useCallback = function(a, b) {
      return U.current.useCallback(a, b);
    };
    exports.useContext = function(a) {
      return U.current.useContext(a);
    };
    exports.useDebugValue = function() {
    };
    exports.useDeferredValue = function(a) {
      return U.current.useDeferredValue(a);
    };
    exports.useEffect = function(a, b) {
      return U.current.useEffect(a, b);
    };
    exports.useId = function() {
      return U.current.useId();
    };
    exports.useImperativeHandle = function(a, b, e) {
      return U.current.useImperativeHandle(a, b, e);
    };
    exports.useInsertionEffect = function(a, b) {
      return U.current.useInsertionEffect(a, b);
    };
    exports.useLayoutEffect = function(a, b) {
      return U.current.useLayoutEffect(a, b);
    };
    exports.useMemo = function(a, b) {
      return U.current.useMemo(a, b);
    };
    exports.useReducer = function(a, b, e) {
      return U.current.useReducer(a, b, e);
    };
    exports.useRef = function(a) {
      return U.current.useRef(a);
    };
    exports.useState = function(a) {
      return U.current.useState(a);
    };
    exports.useSyncExternalStore = function(a, b, e) {
      return U.current.useSyncExternalStore(a, b, e);
    };
    exports.useTransition = function() {
      return U.current.useTransition();
    };
    exports.version = "18.3.1";
  }
});

// node_modules/react/cjs/react.development.js
var require_react_development = __commonJS({
  "node_modules/react/cjs/react.development.js"(exports, module) {
    "use strict";
    if (process.env.NODE_ENV !== "production") {
      (function() {
        "use strict";
        if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart === "function") {
          __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
        }
        var ReactVersion = "18.3.1";
        var REACT_ELEMENT_TYPE = Symbol.for("react.element");
        var REACT_PORTAL_TYPE = Symbol.for("react.portal");
        var REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
        var REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
        var REACT_PROFILER_TYPE = Symbol.for("react.profiler");
        var REACT_PROVIDER_TYPE = Symbol.for("react.provider");
        var REACT_CONTEXT_TYPE = Symbol.for("react.context");
        var REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
        var REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
        var REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list");
        var REACT_MEMO_TYPE = Symbol.for("react.memo");
        var REACT_LAZY_TYPE = Symbol.for("react.lazy");
        var REACT_OFFSCREEN_TYPE = Symbol.for("react.offscreen");
        var MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
        var FAUX_ITERATOR_SYMBOL = "@@iterator";
        function getIteratorFn(maybeIterable) {
          if (maybeIterable === null || typeof maybeIterable !== "object") {
            return null;
          }
          var maybeIterator = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL];
          if (typeof maybeIterator === "function") {
            return maybeIterator;
          }
          return null;
        }
        var ReactCurrentDispatcher = {
          /**
           * @internal
           * @type {ReactComponent}
           */
          current: null
        };
        var ReactCurrentBatchConfig = {
          transition: null
        };
        var ReactCurrentActQueue = {
          current: null,
          // Used to reproduce behavior of `batchedUpdates` in legacy mode.
          isBatchingLegacy: false,
          didScheduleLegacyUpdate: false
        };
        var ReactCurrentOwner = {
          /**
           * @internal
           * @type {ReactComponent}
           */
          current: null
        };
        var ReactDebugCurrentFrame = {};
        var currentExtraStackFrame = null;
        function setExtraStackFrame(stack) {
          {
            currentExtraStackFrame = stack;
          }
        }
        {
          ReactDebugCurrentFrame.setExtraStackFrame = function(stack) {
            {
              currentExtraStackFrame = stack;
            }
          };
          ReactDebugCurrentFrame.getCurrentStack = null;
          ReactDebugCurrentFrame.getStackAddendum = function() {
            var stack = "";
            if (currentExtraStackFrame) {
              stack += currentExtraStackFrame;
            }
            var impl = ReactDebugCurrentFrame.getCurrentStack;
            if (impl) {
              stack += impl() || "";
            }
            return stack;
          };
        }
        var enableScopeAPI = false;
        var enableCacheElement = false;
        var enableTransitionTracing = false;
        var enableLegacyHidden = false;
        var enableDebugTracing = false;
        var ReactSharedInternals = {
          ReactCurrentDispatcher,
          ReactCurrentBatchConfig,
          ReactCurrentOwner
        };
        {
          ReactSharedInternals.ReactDebugCurrentFrame = ReactDebugCurrentFrame;
          ReactSharedInternals.ReactCurrentActQueue = ReactCurrentActQueue;
        }
        function warn(format) {
          {
            {
              for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                args[_key - 1] = arguments[_key];
              }
              printWarning("warn", format, args);
            }
          }
        }
        function error(format) {
          {
            {
              for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
                args[_key2 - 1] = arguments[_key2];
              }
              printWarning("error", format, args);
            }
          }
        }
        function printWarning(level, format, args) {
          {
            var ReactDebugCurrentFrame2 = ReactSharedInternals.ReactDebugCurrentFrame;
            var stack = ReactDebugCurrentFrame2.getStackAddendum();
            if (stack !== "") {
              format += "%s";
              args = args.concat([stack]);
            }
            var argsWithFormat = args.map(function(item) {
              return String(item);
            });
            argsWithFormat.unshift("Warning: " + format);
            Function.prototype.apply.call(console[level], console, argsWithFormat);
          }
        }
        var didWarnStateUpdateForUnmountedComponent = {};
        function warnNoop(publicInstance, callerName) {
          {
            var _constructor = publicInstance.constructor;
            var componentName = _constructor && (_constructor.displayName || _constructor.name) || "ReactClass";
            var warningKey = componentName + "." + callerName;
            if (didWarnStateUpdateForUnmountedComponent[warningKey]) {
              return;
            }
            error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", callerName, componentName);
            didWarnStateUpdateForUnmountedComponent[warningKey] = true;
          }
        }
        var ReactNoopUpdateQueue = {
          /**
           * Checks whether or not this composite component is mounted.
           * @param {ReactClass} publicInstance The instance we want to test.
           * @return {boolean} True if mounted, false otherwise.
           * @protected
           * @final
           */
          isMounted: function(publicInstance) {
            return false;
          },
          /**
           * Forces an update. This should only be invoked when it is known with
           * certainty that we are **not** in a DOM transaction.
           *
           * You may want to call this when you know that some deeper aspect of the
           * component's state has changed but `setState` was not called.
           *
           * This will not invoke `shouldComponentUpdate`, but it will invoke
           * `componentWillUpdate` and `componentDidUpdate`.
           *
           * @param {ReactClass} publicInstance The instance that should rerender.
           * @param {?function} callback Called after component is updated.
           * @param {?string} callerName name of the calling function in the public API.
           * @internal
           */
          enqueueForceUpdate: function(publicInstance, callback, callerName) {
            warnNoop(publicInstance, "forceUpdate");
          },
          /**
           * Replaces all of the state. Always use this or `setState` to mutate state.
           * You should treat `this.state` as immutable.
           *
           * There is no guarantee that `this.state` will be immediately updated, so
           * accessing `this.state` after calling this method may return the old value.
           *
           * @param {ReactClass} publicInstance The instance that should rerender.
           * @param {object} completeState Next state.
           * @param {?function} callback Called after component is updated.
           * @param {?string} callerName name of the calling function in the public API.
           * @internal
           */
          enqueueReplaceState: function(publicInstance, completeState, callback, callerName) {
            warnNoop(publicInstance, "replaceState");
          },
          /**
           * Sets a subset of the state. This only exists because _pendingState is
           * internal. This provides a merging strategy that is not available to deep
           * properties which is confusing. TODO: Expose pendingState or don't use it
           * during the merge.
           *
           * @param {ReactClass} publicInstance The instance that should rerender.
           * @param {object} partialState Next partial state to be merged with state.
           * @param {?function} callback Called after component is updated.
           * @param {?string} Name of the calling function in the public API.
           * @internal
           */
          enqueueSetState: function(publicInstance, partialState, callback, callerName) {
            warnNoop(publicInstance, "setState");
          }
        };
        var assign = Object.assign;
        var emptyObject = {};
        {
          Object.freeze(emptyObject);
        }
        function Component(props, context, updater) {
          this.props = props;
          this.context = context;
          this.refs = emptyObject;
          this.updater = updater || ReactNoopUpdateQueue;
        }
        Component.prototype.isReactComponent = {};
        Component.prototype.setState = function(partialState, callback) {
          if (typeof partialState !== "object" && typeof partialState !== "function" && partialState != null) {
            throw new Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
          }
          this.updater.enqueueSetState(this, partialState, callback, "setState");
        };
        Component.prototype.forceUpdate = function(callback) {
          this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
        };
        {
          var deprecatedAPIs = {
            isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
            replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
          };
          var defineDeprecationWarning = function(methodName, info) {
            Object.defineProperty(Component.prototype, methodName, {
              get: function() {
                warn("%s(...) is deprecated in plain JavaScript React classes. %s", info[0], info[1]);
                return void 0;
              }
            });
          };
          for (var fnName in deprecatedAPIs) {
            if (deprecatedAPIs.hasOwnProperty(fnName)) {
              defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
            }
          }
        }
        function ComponentDummy() {
        }
        ComponentDummy.prototype = Component.prototype;
        function PureComponent(props, context, updater) {
          this.props = props;
          this.context = context;
          this.refs = emptyObject;
          this.updater = updater || ReactNoopUpdateQueue;
        }
        var pureComponentPrototype = PureComponent.prototype = new ComponentDummy();
        pureComponentPrototype.constructor = PureComponent;
        assign(pureComponentPrototype, Component.prototype);
        pureComponentPrototype.isPureReactComponent = true;
        function createRef() {
          var refObject = {
            current: null
          };
          {
            Object.seal(refObject);
          }
          return refObject;
        }
        var isArrayImpl = Array.isArray;
        function isArray(a) {
          return isArrayImpl(a);
        }
        function typeName(value) {
          {
            var hasToStringTag = typeof Symbol === "function" && Symbol.toStringTag;
            var type = hasToStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            return type;
          }
        }
        function willCoercionThrow(value) {
          {
            try {
              testStringCoercion(value);
              return false;
            } catch (e) {
              return true;
            }
          }
        }
        function testStringCoercion(value) {
          return "" + value;
        }
        function checkKeyStringCoercion(value) {
          {
            if (willCoercionThrow(value)) {
              error("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", typeName(value));
              return testStringCoercion(value);
            }
          }
        }
        function getWrappedName(outerType, innerType, wrapperName) {
          var displayName = outerType.displayName;
          if (displayName) {
            return displayName;
          }
          var functionName = innerType.displayName || innerType.name || "";
          return functionName !== "" ? wrapperName + "(" + functionName + ")" : wrapperName;
        }
        function getContextName(type) {
          return type.displayName || "Context";
        }
        function getComponentNameFromType(type) {
          if (type == null) {
            return null;
          }
          {
            if (typeof type.tag === "number") {
              error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue.");
            }
          }
          if (typeof type === "function") {
            return type.displayName || type.name || null;
          }
          if (typeof type === "string") {
            return type;
          }
          switch (type) {
            case REACT_FRAGMENT_TYPE:
              return "Fragment";
            case REACT_PORTAL_TYPE:
              return "Portal";
            case REACT_PROFILER_TYPE:
              return "Profiler";
            case REACT_STRICT_MODE_TYPE:
              return "StrictMode";
            case REACT_SUSPENSE_TYPE:
              return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
              return "SuspenseList";
          }
          if (typeof type === "object") {
            switch (type.$$typeof) {
              case REACT_CONTEXT_TYPE:
                var context = type;
                return getContextName(context) + ".Consumer";
              case REACT_PROVIDER_TYPE:
                var provider = type;
                return getContextName(provider._context) + ".Provider";
              case REACT_FORWARD_REF_TYPE:
                return getWrappedName(type, type.render, "ForwardRef");
              case REACT_MEMO_TYPE:
                var outerName = type.displayName || null;
                if (outerName !== null) {
                  return outerName;
                }
                return getComponentNameFromType(type.type) || "Memo";
              case REACT_LAZY_TYPE: {
                var lazyComponent = type;
                var payload = lazyComponent._payload;
                var init = lazyComponent._init;
                try {
                  return getComponentNameFromType(init(payload));
                } catch (x) {
                  return null;
                }
              }
            }
          }
          return null;
        }
        var hasOwnProperty = Object.prototype.hasOwnProperty;
        var RESERVED_PROPS = {
          key: true,
          ref: true,
          __self: true,
          __source: true
        };
        var specialPropKeyWarningShown, specialPropRefWarningShown, didWarnAboutStringRefs;
        {
          didWarnAboutStringRefs = {};
        }
        function hasValidRef(config) {
          {
            if (hasOwnProperty.call(config, "ref")) {
              var getter = Object.getOwnPropertyDescriptor(config, "ref").get;
              if (getter && getter.isReactWarning) {
                return false;
              }
            }
          }
          return config.ref !== void 0;
        }
        function hasValidKey(config) {
          {
            if (hasOwnProperty.call(config, "key")) {
              var getter = Object.getOwnPropertyDescriptor(config, "key").get;
              if (getter && getter.isReactWarning) {
                return false;
              }
            }
          }
          return config.key !== void 0;
        }
        function defineKeyPropWarningGetter(props, displayName) {
          var warnAboutAccessingKey = function() {
            {
              if (!specialPropKeyWarningShown) {
                specialPropKeyWarningShown = true;
                error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", displayName);
              }
            }
          };
          warnAboutAccessingKey.isReactWarning = true;
          Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: true
          });
        }
        function defineRefPropWarningGetter(props, displayName) {
          var warnAboutAccessingRef = function() {
            {
              if (!specialPropRefWarningShown) {
                specialPropRefWarningShown = true;
                error("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", displayName);
              }
            }
          };
          warnAboutAccessingRef.isReactWarning = true;
          Object.defineProperty(props, "ref", {
            get: warnAboutAccessingRef,
            configurable: true
          });
        }
        function warnIfStringRefCannotBeAutoConverted(config) {
          {
            if (typeof config.ref === "string" && ReactCurrentOwner.current && config.__self && ReactCurrentOwner.current.stateNode !== config.__self) {
              var componentName = getComponentNameFromType(ReactCurrentOwner.current.type);
              if (!didWarnAboutStringRefs[componentName]) {
                error('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', componentName, config.ref);
                didWarnAboutStringRefs[componentName] = true;
              }
            }
          }
        }
        var ReactElement = function(type, key, ref, self, source, owner, props) {
          var element = {
            // This tag allows us to uniquely identify this as a React Element
            $$typeof: REACT_ELEMENT_TYPE,
            // Built-in properties that belong on the element
            type,
            key,
            ref,
            props,
            // Record the component responsible for creating this element.
            _owner: owner
          };
          {
            element._store = {};
            Object.defineProperty(element._store, "validated", {
              configurable: false,
              enumerable: false,
              writable: true,
              value: false
            });
            Object.defineProperty(element, "_self", {
              configurable: false,
              enumerable: false,
              writable: false,
              value: self
            });
            Object.defineProperty(element, "_source", {
              configurable: false,
              enumerable: false,
              writable: false,
              value: source
            });
            if (Object.freeze) {
              Object.freeze(element.props);
              Object.freeze(element);
            }
          }
          return element;
        };
        function createElement(type, config, children) {
          var propName;
          var props = {};
          var key = null;
          var ref = null;
          var self = null;
          var source = null;
          if (config != null) {
            if (hasValidRef(config)) {
              ref = config.ref;
              {
                warnIfStringRefCannotBeAutoConverted(config);
              }
            }
            if (hasValidKey(config)) {
              {
                checkKeyStringCoercion(config.key);
              }
              key = "" + config.key;
            }
            self = config.__self === void 0 ? null : config.__self;
            source = config.__source === void 0 ? null : config.__source;
            for (propName in config) {
              if (hasOwnProperty.call(config, propName) && !RESERVED_PROPS.hasOwnProperty(propName)) {
                props[propName] = config[propName];
              }
            }
          }
          var childrenLength = arguments.length - 2;
          if (childrenLength === 1) {
            props.children = children;
          } else if (childrenLength > 1) {
            var childArray = Array(childrenLength);
            for (var i = 0; i < childrenLength; i++) {
              childArray[i] = arguments[i + 2];
            }
            {
              if (Object.freeze) {
                Object.freeze(childArray);
              }
            }
            props.children = childArray;
          }
          if (type && type.defaultProps) {
            var defaultProps = type.defaultProps;
            for (propName in defaultProps) {
              if (props[propName] === void 0) {
                props[propName] = defaultProps[propName];
              }
            }
          }
          {
            if (key || ref) {
              var displayName = typeof type === "function" ? type.displayName || type.name || "Unknown" : type;
              if (key) {
                defineKeyPropWarningGetter(props, displayName);
              }
              if (ref) {
                defineRefPropWarningGetter(props, displayName);
              }
            }
          }
          return ReactElement(type, key, ref, self, source, ReactCurrentOwner.current, props);
        }
        function cloneAndReplaceKey(oldElement, newKey) {
          var newElement = ReactElement(oldElement.type, newKey, oldElement.ref, oldElement._self, oldElement._source, oldElement._owner, oldElement.props);
          return newElement;
        }
        function cloneElement(element, config, children) {
          if (element === null || element === void 0) {
            throw new Error("React.cloneElement(...): The argument must be a React element, but you passed " + element + ".");
          }
          var propName;
          var props = assign({}, element.props);
          var key = element.key;
          var ref = element.ref;
          var self = element._self;
          var source = element._source;
          var owner = element._owner;
          if (config != null) {
            if (hasValidRef(config)) {
              ref = config.ref;
              owner = ReactCurrentOwner.current;
            }
            if (hasValidKey(config)) {
              {
                checkKeyStringCoercion(config.key);
              }
              key = "" + config.key;
            }
            var defaultProps;
            if (element.type && element.type.defaultProps) {
              defaultProps = element.type.defaultProps;
            }
            for (propName in config) {
              if (hasOwnProperty.call(config, propName) && !RESERVED_PROPS.hasOwnProperty(propName)) {
                if (config[propName] === void 0 && defaultProps !== void 0) {
                  props[propName] = defaultProps[propName];
                } else {
                  props[propName] = config[propName];
                }
              }
            }
          }
          var childrenLength = arguments.length - 2;
          if (childrenLength === 1) {
            props.children = children;
          } else if (childrenLength > 1) {
            var childArray = Array(childrenLength);
            for (var i = 0; i < childrenLength; i++) {
              childArray[i] = arguments[i + 2];
            }
            props.children = childArray;
          }
          return ReactElement(element.type, key, ref, self, source, owner, props);
        }
        function isValidElement(object) {
          return typeof object === "object" && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
        }
        var SEPARATOR = ".";
        var SUBSEPARATOR = ":";
        function escape(key) {
          var escapeRegex = /[=:]/g;
          var escaperLookup = {
            "=": "=0",
            ":": "=2"
          };
          var escapedString = key.replace(escapeRegex, function(match) {
            return escaperLookup[match];
          });
          return "$" + escapedString;
        }
        var didWarnAboutMaps = false;
        var userProvidedKeyEscapeRegex = /\/+/g;
        function escapeUserProvidedKey(text) {
          return text.replace(userProvidedKeyEscapeRegex, "$&/");
        }
        function getElementKey(element, index) {
          if (typeof element === "object" && element !== null && element.key != null) {
            {
              checkKeyStringCoercion(element.key);
            }
            return escape("" + element.key);
          }
          return index.toString(36);
        }
        function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
          var type = typeof children;
          if (type === "undefined" || type === "boolean") {
            children = null;
          }
          var invokeCallback = false;
          if (children === null) {
            invokeCallback = true;
          } else {
            switch (type) {
              case "string":
              case "number":
                invokeCallback = true;
                break;
              case "object":
                switch (children.$$typeof) {
                  case REACT_ELEMENT_TYPE:
                  case REACT_PORTAL_TYPE:
                    invokeCallback = true;
                }
            }
          }
          if (invokeCallback) {
            var _child = children;
            var mappedChild = callback(_child);
            var childKey = nameSoFar === "" ? SEPARATOR + getElementKey(_child, 0) : nameSoFar;
            if (isArray(mappedChild)) {
              var escapedChildKey = "";
              if (childKey != null) {
                escapedChildKey = escapeUserProvidedKey(childKey) + "/";
              }
              mapIntoArray(mappedChild, array, escapedChildKey, "", function(c) {
                return c;
              });
            } else if (mappedChild != null) {
              if (isValidElement(mappedChild)) {
                {
                  if (mappedChild.key && (!_child || _child.key !== mappedChild.key)) {
                    checkKeyStringCoercion(mappedChild.key);
                  }
                }
                mappedChild = cloneAndReplaceKey(
                  mappedChild,
                  // Keep both the (mapped) and old keys if they differ, just as
                  // traverseAllChildren used to do for objects as children
                  escapedPrefix + // $FlowFixMe Flow incorrectly thinks React.Portal doesn't have a key
                  (mappedChild.key && (!_child || _child.key !== mappedChild.key) ? (
                    // $FlowFixMe Flow incorrectly thinks existing element's key can be a number
                    // eslint-disable-next-line react-internal/safe-string-coercion
                    escapeUserProvidedKey("" + mappedChild.key) + "/"
                  ) : "") + childKey
                );
              }
              array.push(mappedChild);
            }
            return 1;
          }
          var child;
          var nextName;
          var subtreeCount = 0;
          var nextNamePrefix = nameSoFar === "" ? SEPARATOR : nameSoFar + SUBSEPARATOR;
          if (isArray(children)) {
            for (var i = 0; i < children.length; i++) {
              child = children[i];
              nextName = nextNamePrefix + getElementKey(child, i);
              subtreeCount += mapIntoArray(child, array, escapedPrefix, nextName, callback);
            }
          } else {
            var iteratorFn = getIteratorFn(children);
            if (typeof iteratorFn === "function") {
              var iterableChildren = children;
              {
                if (iteratorFn === iterableChildren.entries) {
                  if (!didWarnAboutMaps) {
                    warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead.");
                  }
                  didWarnAboutMaps = true;
                }
              }
              var iterator = iteratorFn.call(iterableChildren);
              var step;
              var ii = 0;
              while (!(step = iterator.next()).done) {
                child = step.value;
                nextName = nextNamePrefix + getElementKey(child, ii++);
                subtreeCount += mapIntoArray(child, array, escapedPrefix, nextName, callback);
              }
            } else if (type === "object") {
              var childrenString = String(children);
              throw new Error("Objects are not valid as a React child (found: " + (childrenString === "[object Object]" ? "object with keys {" + Object.keys(children).join(", ") + "}" : childrenString) + "). If you meant to render a collection of children, use an array instead.");
            }
          }
          return subtreeCount;
        }
        function mapChildren(children, func, context) {
          if (children == null) {
            return children;
          }
          var result = [];
          var count = 0;
          mapIntoArray(children, result, "", "", function(child) {
            return func.call(context, child, count++);
          });
          return result;
        }
        function countChildren(children) {
          var n = 0;
          mapChildren(children, function() {
            n++;
          });
          return n;
        }
        function forEachChildren(children, forEachFunc, forEachContext) {
          mapChildren(children, function() {
            forEachFunc.apply(this, arguments);
          }, forEachContext);
        }
        function toArray(children) {
          return mapChildren(children, function(child) {
            return child;
          }) || [];
        }
        function onlyChild(children) {
          if (!isValidElement(children)) {
            throw new Error("React.Children.only expected to receive a single React element child.");
          }
          return children;
        }
        function createContext(defaultValue) {
          var context = {
            $$typeof: REACT_CONTEXT_TYPE,
            // As a workaround to support multiple concurrent renderers, we categorize
            // some renderers as primary and others as secondary. We only expect
            // there to be two concurrent renderers at most: React Native (primary) and
            // Fabric (secondary); React DOM (primary) and React ART (secondary).
            // Secondary renderers store their context values on separate fields.
            _currentValue: defaultValue,
            _currentValue2: defaultValue,
            // Used to track how many concurrent renderers this context currently
            // supports within in a single renderer. Such as parallel server rendering.
            _threadCount: 0,
            // These are circular
            Provider: null,
            Consumer: null,
            // Add these to use same hidden class in VM as ServerContext
            _defaultValue: null,
            _globalName: null
          };
          context.Provider = {
            $$typeof: REACT_PROVIDER_TYPE,
            _context: context
          };
          var hasWarnedAboutUsingNestedContextConsumers = false;
          var hasWarnedAboutUsingConsumerProvider = false;
          var hasWarnedAboutDisplayNameOnConsumer = false;
          {
            var Consumer = {
              $$typeof: REACT_CONTEXT_TYPE,
              _context: context
            };
            Object.defineProperties(Consumer, {
              Provider: {
                get: function() {
                  if (!hasWarnedAboutUsingConsumerProvider) {
                    hasWarnedAboutUsingConsumerProvider = true;
                    error("Rendering <Context.Consumer.Provider> is not supported and will be removed in a future major release. Did you mean to render <Context.Provider> instead?");
                  }
                  return context.Provider;
                },
                set: function(_Provider) {
                  context.Provider = _Provider;
                }
              },
              _currentValue: {
                get: function() {
                  return context._currentValue;
                },
                set: function(_currentValue) {
                  context._currentValue = _currentValue;
                }
              },
              _currentValue2: {
                get: function() {
                  return context._currentValue2;
                },
                set: function(_currentValue2) {
                  context._currentValue2 = _currentValue2;
                }
              },
              _threadCount: {
                get: function() {
                  return context._threadCount;
                },
                set: function(_threadCount) {
                  context._threadCount = _threadCount;
                }
              },
              Consumer: {
                get: function() {
                  if (!hasWarnedAboutUsingNestedContextConsumers) {
                    hasWarnedAboutUsingNestedContextConsumers = true;
                    error("Rendering <Context.Consumer.Consumer> is not supported and will be removed in a future major release. Did you mean to render <Context.Consumer> instead?");
                  }
                  return context.Consumer;
                }
              },
              displayName: {
                get: function() {
                  return context.displayName;
                },
                set: function(displayName) {
                  if (!hasWarnedAboutDisplayNameOnConsumer) {
                    warn("Setting `displayName` on Context.Consumer has no effect. You should set it directly on the context with Context.displayName = '%s'.", displayName);
                    hasWarnedAboutDisplayNameOnConsumer = true;
                  }
                }
              }
            });
            context.Consumer = Consumer;
          }
          {
            context._currentRenderer = null;
            context._currentRenderer2 = null;
          }
          return context;
        }
        var Uninitialized = -1;
        var Pending = 0;
        var Resolved = 1;
        var Rejected = 2;
        function lazyInitializer(payload) {
          if (payload._status === Uninitialized) {
            var ctor = payload._result;
            var thenable = ctor();
            thenable.then(function(moduleObject2) {
              if (payload._status === Pending || payload._status === Uninitialized) {
                var resolved = payload;
                resolved._status = Resolved;
                resolved._result = moduleObject2;
              }
            }, function(error2) {
              if (payload._status === Pending || payload._status === Uninitialized) {
                var rejected = payload;
                rejected._status = Rejected;
                rejected._result = error2;
              }
            });
            if (payload._status === Uninitialized) {
              var pending = payload;
              pending._status = Pending;
              pending._result = thenable;
            }
          }
          if (payload._status === Resolved) {
            var moduleObject = payload._result;
            {
              if (moduleObject === void 0) {
                error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))\n\nDid you accidentally put curly braces around the import?", moduleObject);
              }
            }
            {
              if (!("default" in moduleObject)) {
                error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))", moduleObject);
              }
            }
            return moduleObject.default;
          } else {
            throw payload._result;
          }
        }
        function lazy(ctor) {
          var payload = {
            // We use these fields to store the result.
            _status: Uninitialized,
            _result: ctor
          };
          var lazyType = {
            $$typeof: REACT_LAZY_TYPE,
            _payload: payload,
            _init: lazyInitializer
          };
          {
            var defaultProps;
            var propTypes;
            Object.defineProperties(lazyType, {
              defaultProps: {
                configurable: true,
                get: function() {
                  return defaultProps;
                },
                set: function(newDefaultProps) {
                  error("React.lazy(...): It is not supported to assign `defaultProps` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it.");
                  defaultProps = newDefaultProps;
                  Object.defineProperty(lazyType, "defaultProps", {
                    enumerable: true
                  });
                }
              },
              propTypes: {
                configurable: true,
                get: function() {
                  return propTypes;
                },
                set: function(newPropTypes) {
                  error("React.lazy(...): It is not supported to assign `propTypes` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it.");
                  propTypes = newPropTypes;
                  Object.defineProperty(lazyType, "propTypes", {
                    enumerable: true
                  });
                }
              }
            });
          }
          return lazyType;
        }
        function forwardRef(render) {
          {
            if (render != null && render.$$typeof === REACT_MEMO_TYPE) {
              error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).");
            } else if (typeof render !== "function") {
              error("forwardRef requires a render function but was given %s.", render === null ? "null" : typeof render);
            } else {
              if (render.length !== 0 && render.length !== 2) {
                error("forwardRef render functions accept exactly two parameters: props and ref. %s", render.length === 1 ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined.");
              }
            }
            if (render != null) {
              if (render.defaultProps != null || render.propTypes != null) {
                error("forwardRef render functions do not support propTypes or defaultProps. Did you accidentally pass a React component?");
              }
            }
          }
          var elementType = {
            $$typeof: REACT_FORWARD_REF_TYPE,
            render
          };
          {
            var ownName;
            Object.defineProperty(elementType, "displayName", {
              enumerable: false,
              configurable: true,
              get: function() {
                return ownName;
              },
              set: function(name) {
                ownName = name;
                if (!render.name && !render.displayName) {
                  render.displayName = name;
                }
              }
            });
          }
          return elementType;
        }
        var REACT_MODULE_REFERENCE;
        {
          REACT_MODULE_REFERENCE = Symbol.for("react.module.reference");
        }
        function isValidElementType(type) {
          if (typeof type === "string" || typeof type === "function") {
            return true;
          }
          if (type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || enableDebugTracing || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || enableLegacyHidden || type === REACT_OFFSCREEN_TYPE || enableScopeAPI || enableCacheElement || enableTransitionTracing) {
            return true;
          }
          if (typeof type === "object" && type !== null) {
            if (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || // This needs to include all possible module reference object
            // types supported by any Flight configuration anywhere since
            // we don't know which Flight build this will end up being used
            // with.
            type.$$typeof === REACT_MODULE_REFERENCE || type.getModuleId !== void 0) {
              return true;
            }
          }
          return false;
        }
        function memo(type, compare) {
          {
            if (!isValidElementType(type)) {
              error("memo: The first argument must be a component. Instead received: %s", type === null ? "null" : typeof type);
            }
          }
          var elementType = {
            $$typeof: REACT_MEMO_TYPE,
            type,
            compare: compare === void 0 ? null : compare
          };
          {
            var ownName;
            Object.defineProperty(elementType, "displayName", {
              enumerable: false,
              configurable: true,
              get: function() {
                return ownName;
              },
              set: function(name) {
                ownName = name;
                if (!type.name && !type.displayName) {
                  type.displayName = name;
                }
              }
            });
          }
          return elementType;
        }
        function resolveDispatcher() {
          var dispatcher = ReactCurrentDispatcher.current;
          {
            if (dispatcher === null) {
              error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.");
            }
          }
          return dispatcher;
        }
        function useContext(Context) {
          var dispatcher = resolveDispatcher();
          {
            if (Context._context !== void 0) {
              var realContext = Context._context;
              if (realContext.Consumer === Context) {
                error("Calling useContext(Context.Consumer) is not supported, may cause bugs, and will be removed in a future major release. Did you mean to call useContext(Context) instead?");
              } else if (realContext.Provider === Context) {
                error("Calling useContext(Context.Provider) is not supported. Did you mean to call useContext(Context) instead?");
              }
            }
          }
          return dispatcher.useContext(Context);
        }
        function useState(initialState) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useState(initialState);
        }
        function useReducer(reducer, initialArg, init) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useReducer(reducer, initialArg, init);
        }
        function useRef(initialValue) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useRef(initialValue);
        }
        function useEffect(create, deps) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useEffect(create, deps);
        }
        function useInsertionEffect(create, deps) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useInsertionEffect(create, deps);
        }
        function useLayoutEffect(create, deps) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useLayoutEffect(create, deps);
        }
        function useCallback(callback, deps) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useCallback(callback, deps);
        }
        function useMemo2(create, deps) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useMemo(create, deps);
        }
        function useImperativeHandle(ref, create, deps) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useImperativeHandle(ref, create, deps);
        }
        function useDebugValue(value, formatterFn) {
          {
            var dispatcher = resolveDispatcher();
            return dispatcher.useDebugValue(value, formatterFn);
          }
        }
        function useTransition() {
          var dispatcher = resolveDispatcher();
          return dispatcher.useTransition();
        }
        function useDeferredValue(value) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useDeferredValue(value);
        }
        function useId() {
          var dispatcher = resolveDispatcher();
          return dispatcher.useId();
        }
        function useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot) {
          var dispatcher = resolveDispatcher();
          return dispatcher.useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
        }
        var disabledDepth = 0;
        var prevLog;
        var prevInfo;
        var prevWarn;
        var prevError;
        var prevGroup;
        var prevGroupCollapsed;
        var prevGroupEnd;
        function disabledLog() {
        }
        disabledLog.__reactDisabledLog = true;
        function disableLogs() {
          {
            if (disabledDepth === 0) {
              prevLog = console.log;
              prevInfo = console.info;
              prevWarn = console.warn;
              prevError = console.error;
              prevGroup = console.group;
              prevGroupCollapsed = console.groupCollapsed;
              prevGroupEnd = console.groupEnd;
              var props = {
                configurable: true,
                enumerable: true,
                value: disabledLog,
                writable: true
              };
              Object.defineProperties(console, {
                info: props,
                log: props,
                warn: props,
                error: props,
                group: props,
                groupCollapsed: props,
                groupEnd: props
              });
            }
            disabledDepth++;
          }
        }
        function reenableLogs() {
          {
            disabledDepth--;
            if (disabledDepth === 0) {
              var props = {
                configurable: true,
                enumerable: true,
                writable: true
              };
              Object.defineProperties(console, {
                log: assign({}, props, {
                  value: prevLog
                }),
                info: assign({}, props, {
                  value: prevInfo
                }),
                warn: assign({}, props, {
                  value: prevWarn
                }),
                error: assign({}, props, {
                  value: prevError
                }),
                group: assign({}, props, {
                  value: prevGroup
                }),
                groupCollapsed: assign({}, props, {
                  value: prevGroupCollapsed
                }),
                groupEnd: assign({}, props, {
                  value: prevGroupEnd
                })
              });
            }
            if (disabledDepth < 0) {
              error("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
            }
          }
        }
        var ReactCurrentDispatcher$1 = ReactSharedInternals.ReactCurrentDispatcher;
        var prefix;
        function describeBuiltInComponentFrame(name, source, ownerFn) {
          {
            if (prefix === void 0) {
              try {
                throw Error();
              } catch (x) {
                var match = x.stack.trim().match(/\n( *(at )?)/);
                prefix = match && match[1] || "";
              }
            }
            return "\n" + prefix + name;
          }
        }
        var reentry = false;
        var componentFrameCache;
        {
          var PossiblyWeakMap = typeof WeakMap === "function" ? WeakMap : Map;
          componentFrameCache = new PossiblyWeakMap();
        }
        function describeNativeComponentFrame(fn, construct) {
          if (!fn || reentry) {
            return "";
          }
          {
            var frame = componentFrameCache.get(fn);
            if (frame !== void 0) {
              return frame;
            }
          }
          var control;
          reentry = true;
          var previousPrepareStackTrace = Error.prepareStackTrace;
          Error.prepareStackTrace = void 0;
          var previousDispatcher;
          {
            previousDispatcher = ReactCurrentDispatcher$1.current;
            ReactCurrentDispatcher$1.current = null;
            disableLogs();
          }
          try {
            if (construct) {
              var Fake = function() {
                throw Error();
              };
              Object.defineProperty(Fake.prototype, "props", {
                set: function() {
                  throw Error();
                }
              });
              if (typeof Reflect === "object" && Reflect.construct) {
                try {
                  Reflect.construct(Fake, []);
                } catch (x) {
                  control = x;
                }
                Reflect.construct(fn, [], Fake);
              } else {
                try {
                  Fake.call();
                } catch (x) {
                  control = x;
                }
                fn.call(Fake.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (x) {
                control = x;
              }
              fn();
            }
          } catch (sample) {
            if (sample && control && typeof sample.stack === "string") {
              var sampleLines = sample.stack.split("\n");
              var controlLines = control.stack.split("\n");
              var s = sampleLines.length - 1;
              var c = controlLines.length - 1;
              while (s >= 1 && c >= 0 && sampleLines[s] !== controlLines[c]) {
                c--;
              }
              for (; s >= 1 && c >= 0; s--, c--) {
                if (sampleLines[s] !== controlLines[c]) {
                  if (s !== 1 || c !== 1) {
                    do {
                      s--;
                      c--;
                      if (c < 0 || sampleLines[s] !== controlLines[c]) {
                        var _frame = "\n" + sampleLines[s].replace(" at new ", " at ");
                        if (fn.displayName && _frame.includes("<anonymous>")) {
                          _frame = _frame.replace("<anonymous>", fn.displayName);
                        }
                        {
                          if (typeof fn === "function") {
                            componentFrameCache.set(fn, _frame);
                          }
                        }
                        return _frame;
                      }
                    } while (s >= 1 && c >= 0);
                  }
                  break;
                }
              }
            }
          } finally {
            reentry = false;
            {
              ReactCurrentDispatcher$1.current = previousDispatcher;
              reenableLogs();
            }
            Error.prepareStackTrace = previousPrepareStackTrace;
          }
          var name = fn ? fn.displayName || fn.name : "";
          var syntheticFrame = name ? describeBuiltInComponentFrame(name) : "";
          {
            if (typeof fn === "function") {
              componentFrameCache.set(fn, syntheticFrame);
            }
          }
          return syntheticFrame;
        }
        function describeFunctionComponentFrame(fn, source, ownerFn) {
          {
            return describeNativeComponentFrame(fn, false);
          }
        }
        function shouldConstruct(Component2) {
          var prototype = Component2.prototype;
          return !!(prototype && prototype.isReactComponent);
        }
        function describeUnknownElementTypeFrameInDEV(type, source, ownerFn) {
          if (type == null) {
            return "";
          }
          if (typeof type === "function") {
            {
              return describeNativeComponentFrame(type, shouldConstruct(type));
            }
          }
          if (typeof type === "string") {
            return describeBuiltInComponentFrame(type);
          }
          switch (type) {
            case REACT_SUSPENSE_TYPE:
              return describeBuiltInComponentFrame("Suspense");
            case REACT_SUSPENSE_LIST_TYPE:
              return describeBuiltInComponentFrame("SuspenseList");
          }
          if (typeof type === "object") {
            switch (type.$$typeof) {
              case REACT_FORWARD_REF_TYPE:
                return describeFunctionComponentFrame(type.render);
              case REACT_MEMO_TYPE:
                return describeUnknownElementTypeFrameInDEV(type.type, source, ownerFn);
              case REACT_LAZY_TYPE: {
                var lazyComponent = type;
                var payload = lazyComponent._payload;
                var init = lazyComponent._init;
                try {
                  return describeUnknownElementTypeFrameInDEV(init(payload), source, ownerFn);
                } catch (x) {
                }
              }
            }
          }
          return "";
        }
        var loggedTypeFailures = {};
        var ReactDebugCurrentFrame$1 = ReactSharedInternals.ReactDebugCurrentFrame;
        function setCurrentlyValidatingElement(element) {
          {
            if (element) {
              var owner = element._owner;
              var stack = describeUnknownElementTypeFrameInDEV(element.type, element._source, owner ? owner.type : null);
              ReactDebugCurrentFrame$1.setExtraStackFrame(stack);
            } else {
              ReactDebugCurrentFrame$1.setExtraStackFrame(null);
            }
          }
        }
        function checkPropTypes(typeSpecs, values, location, componentName, element) {
          {
            var has = Function.call.bind(hasOwnProperty);
            for (var typeSpecName in typeSpecs) {
              if (has(typeSpecs, typeSpecName)) {
                var error$1 = void 0;
                try {
                  if (typeof typeSpecs[typeSpecName] !== "function") {
                    var err = Error((componentName || "React class") + ": " + location + " type `" + typeSpecName + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof typeSpecs[typeSpecName] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                    err.name = "Invariant Violation";
                    throw err;
                  }
                  error$1 = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
                } catch (ex) {
                  error$1 = ex;
                }
                if (error$1 && !(error$1 instanceof Error)) {
                  setCurrentlyValidatingElement(element);
                  error("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", componentName || "React class", location, typeSpecName, typeof error$1);
                  setCurrentlyValidatingElement(null);
                }
                if (error$1 instanceof Error && !(error$1.message in loggedTypeFailures)) {
                  loggedTypeFailures[error$1.message] = true;
                  setCurrentlyValidatingElement(element);
                  error("Failed %s type: %s", location, error$1.message);
                  setCurrentlyValidatingElement(null);
                }
              }
            }
          }
        }
        function setCurrentlyValidatingElement$1(element) {
          {
            if (element) {
              var owner = element._owner;
              var stack = describeUnknownElementTypeFrameInDEV(element.type, element._source, owner ? owner.type : null);
              setExtraStackFrame(stack);
            } else {
              setExtraStackFrame(null);
            }
          }
        }
        var propTypesMisspellWarningShown;
        {
          propTypesMisspellWarningShown = false;
        }
        function getDeclarationErrorAddendum() {
          if (ReactCurrentOwner.current) {
            var name = getComponentNameFromType(ReactCurrentOwner.current.type);
            if (name) {
              return "\n\nCheck the render method of `" + name + "`.";
            }
          }
          return "";
        }
        function getSourceInfoErrorAddendum(source) {
          if (source !== void 0) {
            var fileName = source.fileName.replace(/^.*[\\\/]/, "");
            var lineNumber = source.lineNumber;
            return "\n\nCheck your code at " + fileName + ":" + lineNumber + ".";
          }
          return "";
        }
        function getSourceInfoErrorAddendumForProps(elementProps) {
          if (elementProps !== null && elementProps !== void 0) {
            return getSourceInfoErrorAddendum(elementProps.__source);
          }
          return "";
        }
        var ownerHasKeyUseWarning = {};
        function getCurrentComponentErrorInfo(parentType) {
          var info = getDeclarationErrorAddendum();
          if (!info) {
            var parentName = typeof parentType === "string" ? parentType : parentType.displayName || parentType.name;
            if (parentName) {
              info = "\n\nCheck the top-level render call using <" + parentName + ">.";
            }
          }
          return info;
        }
        function validateExplicitKey(element, parentType) {
          if (!element._store || element._store.validated || element.key != null) {
            return;
          }
          element._store.validated = true;
          var currentComponentErrorInfo = getCurrentComponentErrorInfo(parentType);
          if (ownerHasKeyUseWarning[currentComponentErrorInfo]) {
            return;
          }
          ownerHasKeyUseWarning[currentComponentErrorInfo] = true;
          var childOwner = "";
          if (element && element._owner && element._owner !== ReactCurrentOwner.current) {
            childOwner = " It was passed a child from " + getComponentNameFromType(element._owner.type) + ".";
          }
          {
            setCurrentlyValidatingElement$1(element);
            error('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', currentComponentErrorInfo, childOwner);
            setCurrentlyValidatingElement$1(null);
          }
        }
        function validateChildKeys(node, parentType) {
          if (typeof node !== "object") {
            return;
          }
          if (isArray(node)) {
            for (var i = 0; i < node.length; i++) {
              var child = node[i];
              if (isValidElement(child)) {
                validateExplicitKey(child, parentType);
              }
            }
          } else if (isValidElement(node)) {
            if (node._store) {
              node._store.validated = true;
            }
          } else if (node) {
            var iteratorFn = getIteratorFn(node);
            if (typeof iteratorFn === "function") {
              if (iteratorFn !== node.entries) {
                var iterator = iteratorFn.call(node);
                var step;
                while (!(step = iterator.next()).done) {
                  if (isValidElement(step.value)) {
                    validateExplicitKey(step.value, parentType);
                  }
                }
              }
            }
          }
        }
        function validatePropTypes(element) {
          {
            var type = element.type;
            if (type === null || type === void 0 || typeof type === "string") {
              return;
            }
            var propTypes;
            if (typeof type === "function") {
              propTypes = type.propTypes;
            } else if (typeof type === "object" && (type.$$typeof === REACT_FORWARD_REF_TYPE || // Note: Memo only checks outer props here.
            // Inner props are checked in the reconciler.
            type.$$typeof === REACT_MEMO_TYPE)) {
              propTypes = type.propTypes;
            } else {
              return;
            }
            if (propTypes) {
              var name = getComponentNameFromType(type);
              checkPropTypes(propTypes, element.props, "prop", name, element);
            } else if (type.PropTypes !== void 0 && !propTypesMisspellWarningShown) {
              propTypesMisspellWarningShown = true;
              var _name = getComponentNameFromType(type);
              error("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", _name || "Unknown");
            }
            if (typeof type.getDefaultProps === "function" && !type.getDefaultProps.isReactClassApproved) {
              error("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
            }
          }
        }
        function validateFragmentProps(fragment) {
          {
            var keys = Object.keys(fragment.props);
            for (var i = 0; i < keys.length; i++) {
              var key = keys[i];
              if (key !== "children" && key !== "key") {
                setCurrentlyValidatingElement$1(fragment);
                error("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", key);
                setCurrentlyValidatingElement$1(null);
                break;
              }
            }
            if (fragment.ref !== null) {
              setCurrentlyValidatingElement$1(fragment);
              error("Invalid attribute `ref` supplied to `React.Fragment`.");
              setCurrentlyValidatingElement$1(null);
            }
          }
        }
        function createElementWithValidation(type, props, children) {
          var validType = isValidElementType(type);
          if (!validType) {
            var info = "";
            if (type === void 0 || typeof type === "object" && type !== null && Object.keys(type).length === 0) {
              info += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.";
            }
            var sourceInfo = getSourceInfoErrorAddendumForProps(props);
            if (sourceInfo) {
              info += sourceInfo;
            } else {
              info += getDeclarationErrorAddendum();
            }
            var typeString;
            if (type === null) {
              typeString = "null";
            } else if (isArray(type)) {
              typeString = "array";
            } else if (type !== void 0 && type.$$typeof === REACT_ELEMENT_TYPE) {
              typeString = "<" + (getComponentNameFromType(type.type) || "Unknown") + " />";
              info = " Did you accidentally export a JSX literal instead of a component?";
            } else {
              typeString = typeof type;
            }
            {
              error("React.createElement: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", typeString, info);
            }
          }
          var element = createElement.apply(this, arguments);
          if (element == null) {
            return element;
          }
          if (validType) {
            for (var i = 2; i < arguments.length; i++) {
              validateChildKeys(arguments[i], type);
            }
          }
          if (type === REACT_FRAGMENT_TYPE) {
            validateFragmentProps(element);
          } else {
            validatePropTypes(element);
          }
          return element;
        }
        var didWarnAboutDeprecatedCreateFactory = false;
        function createFactoryWithValidation(type) {
          var validatedFactory = createElementWithValidation.bind(null, type);
          validatedFactory.type = type;
          {
            if (!didWarnAboutDeprecatedCreateFactory) {
              didWarnAboutDeprecatedCreateFactory = true;
              warn("React.createFactory() is deprecated and will be removed in a future major release. Consider using JSX or use React.createElement() directly instead.");
            }
            Object.defineProperty(validatedFactory, "type", {
              enumerable: false,
              get: function() {
                warn("Factory.type is deprecated. Access the class directly before passing it to createFactory.");
                Object.defineProperty(this, "type", {
                  value: type
                });
                return type;
              }
            });
          }
          return validatedFactory;
        }
        function cloneElementWithValidation(element, props, children) {
          var newElement = cloneElement.apply(this, arguments);
          for (var i = 2; i < arguments.length; i++) {
            validateChildKeys(arguments[i], newElement.type);
          }
          validatePropTypes(newElement);
          return newElement;
        }
        function startTransition(scope, options) {
          var prevTransition = ReactCurrentBatchConfig.transition;
          ReactCurrentBatchConfig.transition = {};
          var currentTransition = ReactCurrentBatchConfig.transition;
          {
            ReactCurrentBatchConfig.transition._updatedFibers = /* @__PURE__ */ new Set();
          }
          try {
            scope();
          } finally {
            ReactCurrentBatchConfig.transition = prevTransition;
            {
              if (prevTransition === null && currentTransition._updatedFibers) {
                var updatedFibersCount = currentTransition._updatedFibers.size;
                if (updatedFibersCount > 10) {
                  warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.");
                }
                currentTransition._updatedFibers.clear();
              }
            }
          }
        }
        var didWarnAboutMessageChannel = false;
        var enqueueTaskImpl = null;
        function enqueueTask(task) {
          if (enqueueTaskImpl === null) {
            try {
              var requireString = ("require" + Math.random()).slice(0, 7);
              var nodeRequire = module && module[requireString];
              enqueueTaskImpl = nodeRequire.call(module, "timers").setImmediate;
            } catch (_err) {
              enqueueTaskImpl = function(callback) {
                {
                  if (didWarnAboutMessageChannel === false) {
                    didWarnAboutMessageChannel = true;
                    if (typeof MessageChannel === "undefined") {
                      error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning.");
                    }
                  }
                }
                var channel = new MessageChannel();
                channel.port1.onmessage = callback;
                channel.port2.postMessage(void 0);
              };
            }
          }
          return enqueueTaskImpl(task);
        }
        var actScopeDepth = 0;
        var didWarnNoAwaitAct = false;
        function act(callback) {
          {
            var prevActScopeDepth = actScopeDepth;
            actScopeDepth++;
            if (ReactCurrentActQueue.current === null) {
              ReactCurrentActQueue.current = [];
            }
            var prevIsBatchingLegacy = ReactCurrentActQueue.isBatchingLegacy;
            var result;
            try {
              ReactCurrentActQueue.isBatchingLegacy = true;
              result = callback();
              if (!prevIsBatchingLegacy && ReactCurrentActQueue.didScheduleLegacyUpdate) {
                var queue = ReactCurrentActQueue.current;
                if (queue !== null) {
                  ReactCurrentActQueue.didScheduleLegacyUpdate = false;
                  flushActQueue(queue);
                }
              }
            } catch (error2) {
              popActScope(prevActScopeDepth);
              throw error2;
            } finally {
              ReactCurrentActQueue.isBatchingLegacy = prevIsBatchingLegacy;
            }
            if (result !== null && typeof result === "object" && typeof result.then === "function") {
              var thenableResult = result;
              var wasAwaited = false;
              var thenable = {
                then: function(resolve, reject) {
                  wasAwaited = true;
                  thenableResult.then(function(returnValue2) {
                    popActScope(prevActScopeDepth);
                    if (actScopeDepth === 0) {
                      recursivelyFlushAsyncActWork(returnValue2, resolve, reject);
                    } else {
                      resolve(returnValue2);
                    }
                  }, function(error2) {
                    popActScope(prevActScopeDepth);
                    reject(error2);
                  });
                }
              };
              {
                if (!didWarnNoAwaitAct && typeof Promise !== "undefined") {
                  Promise.resolve().then(function() {
                  }).then(function() {
                    if (!wasAwaited) {
                      didWarnNoAwaitAct = true;
                      error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);");
                    }
                  });
                }
              }
              return thenable;
            } else {
              var returnValue = result;
              popActScope(prevActScopeDepth);
              if (actScopeDepth === 0) {
                var _queue = ReactCurrentActQueue.current;
                if (_queue !== null) {
                  flushActQueue(_queue);
                  ReactCurrentActQueue.current = null;
                }
                var _thenable = {
                  then: function(resolve, reject) {
                    if (ReactCurrentActQueue.current === null) {
                      ReactCurrentActQueue.current = [];
                      recursivelyFlushAsyncActWork(returnValue, resolve, reject);
                    } else {
                      resolve(returnValue);
                    }
                  }
                };
                return _thenable;
              } else {
                var _thenable2 = {
                  then: function(resolve, reject) {
                    resolve(returnValue);
                  }
                };
                return _thenable2;
              }
            }
          }
        }
        function popActScope(prevActScopeDepth) {
          {
            if (prevActScopeDepth !== actScopeDepth - 1) {
              error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
            }
            actScopeDepth = prevActScopeDepth;
          }
        }
        function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
          {
            var queue = ReactCurrentActQueue.current;
            if (queue !== null) {
              try {
                flushActQueue(queue);
                enqueueTask(function() {
                  if (queue.length === 0) {
                    ReactCurrentActQueue.current = null;
                    resolve(returnValue);
                  } else {
                    recursivelyFlushAsyncActWork(returnValue, resolve, reject);
                  }
                });
              } catch (error2) {
                reject(error2);
              }
            } else {
              resolve(returnValue);
            }
          }
        }
        var isFlushing = false;
        function flushActQueue(queue) {
          {
            if (!isFlushing) {
              isFlushing = true;
              var i = 0;
              try {
                for (; i < queue.length; i++) {
                  var callback = queue[i];
                  do {
                    callback = callback(true);
                  } while (callback !== null);
                }
                queue.length = 0;
              } catch (error2) {
                queue = queue.slice(i + 1);
                throw error2;
              } finally {
                isFlushing = false;
              }
            }
          }
        }
        var createElement$1 = createElementWithValidation;
        var cloneElement$1 = cloneElementWithValidation;
        var createFactory = createFactoryWithValidation;
        var Children = {
          map: mapChildren,
          forEach: forEachChildren,
          count: countChildren,
          toArray,
          only: onlyChild
        };
        exports.Children = Children;
        exports.Component = Component;
        exports.Fragment = REACT_FRAGMENT_TYPE;
        exports.Profiler = REACT_PROFILER_TYPE;
        exports.PureComponent = PureComponent;
        exports.StrictMode = REACT_STRICT_MODE_TYPE;
        exports.Suspense = REACT_SUSPENSE_TYPE;
        exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ReactSharedInternals;
        exports.act = act;
        exports.cloneElement = cloneElement$1;
        exports.createContext = createContext;
        exports.createElement = createElement$1;
        exports.createFactory = createFactory;
        exports.createRef = createRef;
        exports.forwardRef = forwardRef;
        exports.isValidElement = isValidElement;
        exports.lazy = lazy;
        exports.memo = memo;
        exports.startTransition = startTransition;
        exports.unstable_act = act;
        exports.useCallback = useCallback;
        exports.useContext = useContext;
        exports.useDebugValue = useDebugValue;
        exports.useDeferredValue = useDeferredValue;
        exports.useEffect = useEffect;
        exports.useId = useId;
        exports.useImperativeHandle = useImperativeHandle;
        exports.useInsertionEffect = useInsertionEffect;
        exports.useLayoutEffect = useLayoutEffect;
        exports.useMemo = useMemo2;
        exports.useReducer = useReducer;
        exports.useRef = useRef;
        exports.useState = useState;
        exports.useSyncExternalStore = useSyncExternalStore;
        exports.useTransition = useTransition;
        exports.version = ReactVersion;
        if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop === "function") {
          __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
        }
      })();
    }
  }
});

// node_modules/react/index.js
var require_react = __commonJS({
  "node_modules/react/index.js"(exports, module) {
    "use strict";
    if (process.env.NODE_ENV === "production") {
      module.exports = require_react_production_min();
    } else {
      module.exports = require_react_development();
    }
  }
});

// src/coreEngine.jsx
var import_react2 = __toESM(require_react(), 1);

// src/useBiochimico.js
var import_react = __toESM(require_react(), 1);
var TARGETS = {
  macro: { prot: 140, carb: 300, fatTotal: 85, fibre: 30 },
  amino: { leu: 2900, iso: 1500, val: 1900, lys: 2200, met: 1100, phe: 1800, thr: 1100, trp: 300, his: 750 },
  vit: { vitA: 900, vitB1: 1.2, vitB2: 1.3, vitB3: 16, vitB5: 5, vitB6: 1.3, b9: 400, vitB12: 2.4, vitc: 90, vitD: 15, vitE: 15, vitK: 120 },
  min: { ca: 1e3, fe: 18, mg: 420, p: 700, k: 3400, na: 2e3, zn: 11, cu: 0.9, se: 55 },
  fat: { fatSat: 20, fatTrans: 2, fatMono: 45, fatPoly: 20, omega3: 2, omega6: 10, colest: 300 }
};
var ALL_NUTRIENT_KEYS = Object.values(TARGETS).flatMap((g) => Object.keys(g));

// src/coreEngine.jsx
var RADIAN = Math.PI / 180;
var MEAL_TYPE_GROUPS = {
  colazione: ["colazione", "merenda1"],
  snack: ["snack", "merenda_am", "merenda_pm", "merenda2", "spuntino"],
  pranzo: ["pranzo"],
  cena: ["cena"]
};
var MEAL_TYPE_TO_CANONICAL = {};
Object.entries(MEAL_TYPE_GROUPS).forEach(([canonical, aliases]) => {
  aliases.forEach((alias) => {
    MEAL_TYPE_TO_CANONICAL[alias] = canonical;
  });
});
var KNOWLEDGE_BASE_MAX_AGE_MS = 3 * 24 * 60 * 60 * 1e3;
var FOOD_CATEGORY_PROTEINA = "proteina";
var FOOD_CATEGORY_CARBO = "carbo";
var FOOD_CATEGORY_GRASSO = "grasso";
var SWAP_CATEGORY_DEFAULT_MACRO_PER100 = {
  [FOOD_CATEGORY_PROTEINA]: 22,
  [FOOD_CATEGORY_CARBO]: 60,
  [FOOD_CATEGORY_GRASSO]: 40
};

// src/features/salaComandi/engines/sleepCoachEngine.js
var ALCOHOL_WORD_RE = /\b(alcol|birra|vino|prosecco|champagne|whisk(e)?y|vodka|gin|rum|tequila|cocktail|spritz|aperol|liqueur|beer|wine|shot)\b/i;
var INTENSE_WORKOUT_RE = /\b(hiit|tabata|circuit|spinning|spin\b|crossfit|corsa|run|running|sprint|trail|trail run|lifting heavy|squat|corsa\b|allenamento\s+intenso)/i;
function clampDec(h) {
  const n = numericHourRaw(h);
  if (n === null) return null;
  if (n < 0 || n >= 24) return null;
  return n;
}
function parseIsoHour(isoLike) {
  if (isoLike == null) return null;
  const d = typeof isoLike === "string" || isoLike instanceof Date ? new Date(isoLike) : null;
  if (!d || Number.isNaN(d.getTime())) return null;
  return d.getHours() + d.getMinutes() / 60 + d.getSeconds() / 3600;
}
function numericHourRaw(v) {
  if (v == null || v === "") return null;
  if (v instanceof Date) {
    const h = v.getHours() + v.getMinutes() / 60 + v.getSeconds() / 3600;
    return Number.isFinite(h) ? h : null;
  }
  if (typeof v === "string") {
    const s = v.trim().replace(",", ".");
    if (!s) return null;
    const n2 = Number(s);
    return Number.isFinite(n2) ? n2 : null;
  }
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}
function eventClockHourFromEntry(e) {
  if (!e || typeof e !== "object") return null;
  const keys = [e.mealTime, e.time, e.startTime, e.hour];
  for (let i = 0; i < keys.length; i += 1) {
    const c = clampDec(keys[i]);
    if (c != null) return c;
  }
  if (typeof e.timeLabel === "string") {
    const m = String(e.timeLabel).match(/\b(\d{1,2})[:.](\d{2})\b/);
    if (m) return clampDec(parseInt(m[1], 10) + parseInt(m[2], 10) / 60);
  }
  return null;
}
function incidentClockHour(inc) {
  if (!inc || typeof inc !== "object") return null;
  const raw = inc.decimalHour != null ? inc.decimalHour : inc.time;
  return clampDec(raw);
}
function numericOrNull(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}
function sumFoodKcalFromEntry(e) {
  if (!e) return 0;
  let sum = numericOrNull(e.kcal ?? e.cal) ?? 0;
  if (Array.isArray(e.items)) {
    for (const it of e.items) {
      if (!it) continue;
      const k = numericOrNull(it.kcal ?? it.cal);
      if (k != null) sum += k;
    }
  }
  return Math.max(0, sum);
}
function entryPrimaryLabel(e) {
  const s = String(e.desc || e.title || e.name || e.label || "").trim() || String(e.microDesc || "").trim() || String(e.category || "").trim();
  return s;
}
function mentionsAlcohol(entry) {
  if (!entry || typeof entry !== "object") return false;
  if (entry.type === "alcohol") return true;
  if (Boolean(entry.alcohol)) return true;
  const lbl = `${entryPrimaryLabel(entry)} ${String(entry.ingredients || "").toLowerCase()}`.toLowerCase();
  return ALCOHOL_WORD_RE.test(lbl);
}
function normalizeLabel(s) {
  return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
function caffeineEntryTextBlob(e) {
  if (!e || typeof e !== "object") return "";
  return [
    e.name,
    e.label,
    e.title,
    e.foodName,
    e.description,
    e.desc,
    e.microDesc
  ].map((p) => String(p ?? "").trim()).filter(Boolean).join(" ");
}
function caffeineClockNumberForLog(entry) {
  const c = eventClockHourFromEntry(entry);
  if (c != null && Number.isFinite(Number(c))) return Number(c);
  const v = numericHourRaw(entry.time ?? entry.mealTime ?? entry.startTime ?? entry.hour);
  return v != null && Number.isFinite(v) ? Number(v) : Number.NaN;
}
function normalizeCaffeineFromEntry(entry) {
  if (!entry || typeof entry !== "object") {
    return { isCaffeine: false, caffeineLog: null };
  }
  const type = String(entry.type || "").trim().toLowerCase();
  const amountMg = numericOrNull(entry.caffeineMg ?? entry.caffeinaMg) ?? 80;
  const time = caffeineClockNumberForLog(entry);
  const make = (isCaffeine) => ({
    isCaffeine,
    caffeineLog: isCaffeine ? { time, amountMg } : null
  });
  if (type === "stimulant") {
    return make(true);
  }
  const blob = normalizeLabel(caffeineEntryTextBlob(entry));
  if (!blob) return make(false);
  let hit = false;
  if (blob.includes("energy drink")) hit = true;
  else if (blob.includes("cappuccino")) hit = true;
  else if (blob.includes("espresso")) hit = true;
  else if (blob.includes("coffee")) hit = true;
  else if (blob.includes("caffeine")) hit = true;
  else if (blob.includes("caffeina")) hit = true;
  else if (blob.includes("caffe")) hit = true;
  return make(hit);
}
function workoutIsIntense(e) {
  if (!e) return false;
  const i = numericOrNull(e.intensity01 ?? e.intensityPercent);
  if (i != null && i >= 70) return true;
  const label = normalizeLabel(entryPrimaryLabel(e) + String(e.workoutType || ""));
  if (INTENSE_WORKOUT_RE.test(label)) return true;
  const dur = numericOrNull(e.duration);
  const kcal = numericOrNull(e.kcal ?? e.cal);
  if (dur != null && kcal != null && dur >= 35 && kcal >= 380) return true;
  if (kcal != null && kcal >= 380 && (dur == null || !Number.isFinite(Number(e.duration)))) return true;
  return false;
}
function hoursBeforeApproxBedtime(eventDecimal, bedtimeDecimal, wakeDecimal) {
  const ev = clampDec(eventDecimal);
  let bed = clampDec(bedtimeDecimal);
  if (bed == null) return null;
  if (ev == null) return null;
  const w = clampDec(wakeDecimal);
  if (w != null && ev >= w && ev < w + 5) return null;
  let diff = bed - ev;
  if (diff >= 0) return diff;
  if (ev >= 12) diff = bed + (24 - ev);
  else diff += 24;
  if (diff < 0 || diff > 20) return null;
  return diff;
}
function deriveSleepQualityTier(sleepEntry) {
  const e = sleepEntry;
  if (!e || typeof e !== "object") return "unknown";
  const ql = normalizeLabel(String(e.quality ?? e.sleepQuality ?? e.qualityScore ?? "").trim());
  if (/\bpoor|male|bad|worst\b/.test(ql) || /\b(scars|pessim|inferior|turbolent)\w*/.test(ql)) return "poor";
  if (/^\d+$/.test(ql.trim())) {
    const n = Number(ql.trim());
    if (n <= 4) return "poor";
    if (n <= 6) return "fair";
    return "good";
  }
  if (/\bmolto\s+buen|ottiim|excel|eccell/.test(ql)) return "good";
  if (/buono|fair|ok|moderat/.test(ql)) return "fair";
  const h = numericOrNull(e.hours) ?? numericOrNull(e.duration);
  const deepMin = numericOrNull(e.deepMin ?? e.deep);
  const remMin = numericOrNull(e.remMin ?? e.rem);
  if (deepMin != null && remMin != null && h != null && h > 0.5) {
    const restorative = deepMin + remMin;
    const ratio = restorative / (h * 60);
    if (ratio < 0.22) return "poor";
    if (ratio < 0.32) return "fair";
    return "good";
  }
  const score = numericOrNull(e.score ?? e.scoreTotal);
  if (score != null) {
    if (score <= 45) return "poor";
    if (score <= 70) return "fair";
    return "good";
  }
  return "unknown";
}
function normalizeSleepLog(entry) {
  const sleepStart = entry.sleepStart ?? entry.bedtime ?? entry.time ?? null;
  const sleepEnd = entry.sleepEnd ?? entry.wakeTime ?? null;
  const durationHours = entry.hours ?? entry.duration ?? entry.sleepHours ?? null;
  return {
    sleepStart: Number(sleepStart),
    sleepEnd: Number(sleepEnd),
    durationHours: Number(durationHours),
    subjectiveQuality: entry.quality ?? null
  };
}
function extractSleepPrimitives(sleepEntries, fallbackBedDecimal) {
  let duration = null;
  let sleepStartHour = null;
  let wakeHour = null;
  const first = sleepEntries.find(Boolean);
  for (const s of sleepEntries) {
    if (!s || typeof s !== "object") continue;
    const n = normalizeSleepLog(s);
    let h = numericOrNull(n.durationHours);
    if (h == null)
      h = numericOrNull(s.hours ?? s.durationHours ?? (s.duration && s.duration < 48 ? s.duration : null));
    if (h != null && h > 0 && h <= 18) duration = duration == null ? h : Math.max(duration, h);
    let ss = clampDec(numericOrNull(n.sleepStart));
    if (ss == null) {
      const raw = numericOrNull(s.sleepStartHour) ?? parseIsoHour(s.sleepStart ?? s.sleepStartTs);
      if (raw != null) ss = clampDec(raw);
    }
    if (ss != null) sleepStartHour = ss;
    let we = clampDec(numericOrNull(n.sleepEnd));
    if (we == null) {
      const raw = numericOrNull(s.wakeHour) ?? parseIsoHour(s.wakeTime ?? s.sleepEnd ?? s.wakeTs);
      if (raw != null) we = clampDec(raw);
    }
    if (we != null) wakeHour = we;
  }
  let bedtimeApprox = clampDec(first?.bedtimeApprox);
  if (bedtimeApprox == null) bedtimeApprox = clampDec(sleepStartHour);
  if (bedtimeApprox == null && wakeHour != null && duration != null) {
    let b = wakeHour - duration;
    while (b < 0) b += 24;
    while (b >= 24) b -= 24;
    bedtimeApprox = clampDec(b);
  } else if (bedtimeApprox == null && sleepStartHour != null) {
    bedtimeApprox = clampDec(sleepStartHour);
  }
  if (bedtimeApprox == null) bedtimeApprox = clampDec(fallbackBedDecimal);
  const qualityTier = deriveSleepQualityTier(first);
  return {
    durationHours: duration,
    bedtimeApprox,
    wakeApprox: wakeHour,
    sleepQualityTier: qualityTier
  };
}
function buildSleepCoachInputFromDailyLog(activeLog, options = {}) {
  const log = Array.isArray(activeLog) ? activeLog : [];
  const defaultBed = clampDec(options.defaultSleepOnsetDecimal ?? options.defaultSleepOnsetHour ?? 23) ?? 23;
  const wakeHint = clampDec(options.wakeHourDecimal);
  const balance = numericOrNull(options.calorieBalanceApprox);
  const incidents = [];
  const rawSleepTouches = [];
  for (let i = 0; i < log.length; i += 1) {
    const e = log[i];
    if (!e || typeof e !== "object") continue;
    const t = String(e.type || "").trim().toLowerCase();
    if (t === "sleep" || e.id === "sonno") {
      rawSleepTouches.push(e);
      continue;
    }
    if (t === "nap") {
      const clock = eventClockHourFromEntry(e);
      const dNum = numericOrNull(e.duration);
      const mins = numericOrNull(e.durationMin ?? e.minutes) ?? (dNum != null && dNum >= 0 && dNum < 24 ? dNum * 60 : null);
      const hours = mins != null ? mins / 60 : dNum;
      incidents.push({
        kind: "nap",
        decimalHour: clock,
        time: clock,
        durationHours: hours,
        durationMin: mins,
        label: entryPrimaryLabel(e) || "nap"
      });
      continue;
    }
    if (t === "workout" || t === "work" || t === "activity") {
      const clock = eventClockHourFromEntry(e);
      incidents.push({
        kind: "workout",
        decimalHour: clock,
        time: clock,
        intensity: workoutIsIntense(e) ? "high" : "moderate",
        kcalBurn: numericOrNull(e.kcal ?? e.cal),
        label: entryPrimaryLabel(e) || String(e.desc || "workout"),
        meta: { raw: { duration: e.duration } }
      });
      continue;
    }
    if (t === "stimulant") {
      const clock = eventClockHourFromEntry(e);
      const cafS = normalizeCaffeineFromEntry(e);
      incidents.push({
        kind: "stimulant",
        decimalHour: clock,
        time: clock,
        label: entryPrimaryLabel(e) || "stimolo",
        hasCaffeineGuess: true,
        caffeineLog: cafS.caffeineLog
      });
      continue;
    }
    if (t === "alcohol") {
      const clock = eventClockHourFromEntry(e);
      incidents.push({
        kind: "alcohol",
        decimalHour: clock,
        time: clock,
        label: entryPrimaryLabel(e) || "alcol"
      });
      continue;
    }
    if (t === "food" || t === "recipe") {
      const k = sumFoodKcalFromEntry(e);
      const clock = eventClockHourFromEntry(e);
      const cafNorm = normalizeCaffeineFromEntry(e);
      incidents.push({
        kind: "food",
        decimalHour: clock,
        time: clock,
        kcalTotal: k,
        hasAlcoholGuess: mentionsAlcohol(e),
        hasCaffeineGuess: cafNorm.isCaffeine,
        caffeineLog: cafNorm.caffeineLog,
        mealTypeHint: String(e.mealType || e.mealId || ""),
        label: entryPrimaryLabel(e) || t
      });
      continue;
    }
    if (t === "meal" && Array.isArray(e.items)) {
      let total = 0;
      let alc = false;
      let cafItem = false;
      let labelBits = "";
      for (const it of e.items) {
        total += numericOrNull(it?.kcal ?? it?.cal) ?? 0;
        labelBits += ` ${entryPrimaryLabel(it)}`;
        if (mentionsAlcohol(it)) alc = true;
        if (normalizeCaffeineFromEntry(it).isCaffeine) cafItem = true;
      }
      const clock = eventClockHourFromEntry(e);
      const cafMerged = normalizeCaffeineFromEntry({
        ...e,
        desc: `${e.desc || ""}${labelBits}`.trim()
      });
      const isCaffeine = cafItem || cafMerged.isCaffeine;
      const caffeineLog = isCaffeine ? {
        time: caffeineClockNumberForLog(e),
        amountMg: numericOrNull(e.caffeineMg ?? e.caffeinaMg) ?? 80
      } : null;
      incidents.push({
        kind: "meal_aggregate",
        decimalHour: clock,
        time: clock,
        kcalTotal: Math.max(total, numericOrNull(e.kcal ?? e.cal) ?? 0),
        hasAlcoholGuess: alc || mentionsAlcohol({ desc: `${e.desc}${labelBits}` }),
        hasCaffeineGuess: isCaffeine,
        caffeineLog,
        mealTypeHint: String(e.mealId || ""),
        label: String(e.desc || "pasto")
      });
    }
  }
  const extracted = extractSleepPrimitives(rawSleepTouches, defaultBed);
  const sleepAssessmentBase = {
    durationHoursResolved: extracted.durationHours,
    qualityTierResolved: extracted.sleepQualityTier,
    bedtimeDecimalResolved: extracted.bedtimeApprox,
    wakeDecimalResolved: wakeHint ?? extracted.wakeApprox ?? null
  };
  return {
    dateKey: typeof options.referenceDateISO === "string" ? options.referenceDateISO.slice(0, 10) : null,
    sleep: sleepAssessmentBase,
    calorieBalanceApprox: balance ?? null,
    incidents,
    _wakeHintMerged: wakeHint ?? extracted.wakeApprox ?? null,
    _fallbackBedHour: extracted.bedtimeApprox ?? defaultBed
  };
}
var SEVERITY_ORDER = { high: 3, moderate: 2, low: 1 };
function sortCauses(cs) {
  return [...cs].sort((a, b) => {
    const cd = Number(b.confidence ?? 0) - Number(a.confidence ?? 0);
    if (cd !== 0) return cd;
    const sd = SEVERITY_ORDER[b.severity] - SEVERITY_ORDER[a.severity];
    if (sd !== 0) return sd;
    return String(a.id || "").localeCompare(String(b.id || ""));
  });
}
function buildSleepAssessment(norm) {
  const h = norm?.sleep?.durationHoursResolved;
  const q = norm?.sleep?.qualityTierResolved ?? "unknown";
  const hrs = numericOrNull(h);
  const short = hrs != null && hrs < 6;
  const poorQ = q === "poor";
  return {
    hours: hrs,
    qualityTier: q,
    problemFromDuration: Boolean(short),
    problemFromQuality: Boolean(poorQ),
    problematic: Boolean(short || poorQ),
    summary: hrs == null && q === "unknown" ? "Nessuna misura affidabile delle ore di sonno o della qualit\xE0 segnata." : `${hrs != null ? `${hrs.toFixed(1)}h` : "\u2014"} \xB7 qualit\xE0 ${q}`
  };
}
function causeLateCaffeine(incidents, bedtimeDec, wakeDec) {
  const hits = [];
  for (const inc of incidents) {
    if (!inc) continue;
    const stimOk = inc.kind === "food" || inc.kind === "meal_aggregate" || inc.kind === "stimulant";
    if (!stimOk) continue;
    const guessed = inc.kind === "stimulant" ? true : Boolean(inc.hasCaffeineGuess) || inc.caffeineLog != null;
    if (!guessed) continue;
    const dh = incidentClockHour(inc);
    if (dh == null) continue;
    const hrsBefore = hoursBeforeApproxBedtime(dh, bedtimeDec ?? 23, wakeDec);
    if (dh >= 14) {
      const conf = dh >= 18 ? 0.88 : hrsBefore != null && hrsBefore <= 8 ? Math.min(0.9, 0.55 + (8 - hrsBefore) / 35) : 0.72;
      hits.push({
        eventHour: dh,
        hoursBeforeSleep: hrsBefore,
        confidence: conf
      });
    }
  }
  if (!hits.length) return null;
  hits.sort((a, b) => b.confidence - a.confidence);
  const pick = hits[0];
  return {
    id: "late_caffeine",
    label: "Caffeina tardiva",
    severity: pick.eventHour >= 17 || pick.hoursBeforeSleep != null && pick.hoursBeforeSleep <= 6 ? "high" : "moderate",
    confidence: clamp01(pick.confidence),
    evidence: [
      `Dal diario: ingestione/ricetta con caffeina alle ${pick.eventHour.toFixed(2)}\u202Fh.`,
      ...pick.eventHour >= 14 ? [`Dopo il cutoff delle 14:00 (finestra pi\xF9 sensibile alla notte seguente).`] : []
    ].filter(Boolean),
    recommendation: {
      title: "Sposta prima la caffeina",
      action: "Prova caffeina prima delle 13\u201314\u202Fh o riduci dose serale.",
      reason: "La caffeina tardiva aumenta ritardo nel sonolenza e frammentazione notturna (euristica giornaliero)."
    }
  };
}
function causeLateWorkout(incidents, bedtimeDec, wakeDec) {
  const hits = [];
  for (const inc of incidents) {
    if (inc.kind !== "workout") continue;
    if (inc.intensity !== "high") continue;
    const dh = incidentClockHour(inc);
    if (dh == null) continue;
    const gap = hoursBeforeApproxBedtime(dh, bedtimeDec ?? 23, wakeDec);
    if (gap != null && gap <= 4) {
      hits.push({ gap, dh, label: inc.label });
    }
  }
  if (!hits.length) return null;
  hits.sort((a, b) => a.gap - b.gap);
  const pick = hits[0];
  return {
    id: "late_intense_workout",
    label: "Allenamento intenso a ridosso della notte",
    severity: pick.gap <= 2 ? "high" : "moderate",
    confidence: clamp01(0.55 + (4 - pick.gap) / 12),
    evidence: [`Workout marcato come intenso intorno alle ${pick.dh.toFixed(2)}\u202Fh (${pick.gap.toFixed(1)}\u202Fh prima del presunto ritiro a dormire).`],
    recommendation: {
      title: "Anticipa o alleggerisci il carico ",
      action: "Sposta sessioni HIIT/cardio prima del pomeriggio o finale pi\xF9 graduato.",
      reason: "L\u2019attivazione simpatica alta nelle ore immediatamente precedenti il sonno rende pi\xF9 difficile addormentarsi (euristica)."
    }
  };
}
function causeLateHeavyMeal(incidents, bedtimeDec, wakeDec) {
  const hits = [];
  for (const inc of incidents) {
    if (inc.kind !== "food" && inc.kind !== "meal_aggregate") continue;
    const k = numericOrNull(inc.kcalTotal);
    if (k == null || k <= 700) continue;
    const dh = incidentClockHour(inc);
    if (dh == null) continue;
    const gap = hoursBeforeApproxBedtime(dh, bedtimeDec ?? 23, wakeDec);
    if (gap != null && gap <= 3) {
      hits.push({ k, dh, gap, label: inc.label });
    }
  }
  if (!hits.length) return null;
  hits.sort((a, b) => a.gap - b.gap);
  const pick = hits[0];
  return {
    id: "late_heavy_meal",
    label: "Pasto calorie-denso vicino alla nanna",
    severity: pick.k >= 950 ? "high" : "moderate",
    confidence: clamp01(0.6 + Math.min((pick.k - 700) / 1200, 0.35)),
    evidence: [`Pasto/ricetta ~${Math.round(pick.k)}\u202Fkcal a ${pick.dh.toFixed(2)}\u202Fh (${pick.gap.toFixed(1)}\u202Fh dalla notte presumibile).`],
    recommendation: {
      title: "Cena pi\xF9 leggera o anticipata ",
      action: "Obiettivo: pasto grande almeno 3\u20134\u202Fh prima del sonno.",
      reason: "Il carico digestivo alto riduce il comfort gastrointestinale nei primi cicli della notte (euristica)."
    }
  };
}
function causeEveningAlcohol(incidents, bedtimeDec, wakeDec) {
  const hits = [];
  const pushHit = (dh, lbl) => {
    const gap = hoursBeforeApproxBedtime(dh, bedtimeDec ?? 23, wakeDec);
    if (gap != null && gap <= 6) hits.push({ dh, gap, label: lbl });
  };
  for (const inc of incidents) {
    if (inc.kind === "alcohol") {
      const dh2 = incidentClockHour(inc);
      if (dh2 != null) pushHit(dh2, inc.label);
      continue;
    }
    const guess = Boolean(inc.hasAlcoholGuess) || mentionsAlcohol(inc);
    if (!(inc.kind === "food" || inc.kind === "meal_aggregate") || !guess) continue;
    const dh = incidentClockHour(inc);
    if (dh != null) pushHit(dh, inc.label || "consumo inferito da nome/ricetta");
  }
  if (!hits.length) return null;
  hits.sort((a, b) => a.gap - b.gap);
  const pick = hits[0];
  return {
    id: "evening_alcohol",
    label: "Alcool in finestra vicina alla notte",
    severity: pick.gap <= 3 ? "high" : "moderate",
    confidence: clamp01(0.65 + (6 - pick.gap) / 35),
    evidence: [`Consumo (o inferenza da ricetta/nome) circa alle ${pick.dh.toFixed(2)}\u202Fh, ${pick.gap.toFixed(1)}\u202Fh prima del presumibile ritiro.`],
    recommendation: {
      title: "Riduci o anticipa ",
      action: "Tieni pi\xF9 distanza dall\u2019alcool nei 6\u202Fh prima del sonno quando possibile.",
      reason: "L'alcol frammenta i cicli REM e aumenta risvegli tardivi anche se accelera il sonnecchiare."
    }
  };
}
function causeLateNap(incidents) {
  const suspects = incidents.filter((i) => i.kind === "nap");
  if (!suspects.length) return null;
  let worst = null;
  let score = 0;
  for (const n of suspects) {
    const dur = numericOrNull(n.durationHours ?? (n.durationMin != null ? n.durationMin / 60 : null));
    const dh = incidentClockHour(n);
    const long = dur != null && dur > 90 / 60;
    const late = dh != null && dh >= 15;
    if (!long && !late) continue;
    const locScore = (long ? 2 : 0) + (late ? 2 : 0) + Math.min(dur || 0, 3);
    if (locScore > score) {
      score = locScore;
      worst = { n, long, late, dur, dh };
    }
  }
  if (!worst) return null;
  return {
    id: "late_nap",
    label: worst.long ? "Nap lungo" : "Nap tardivo",
    severity: worst.long && worst.late ? "high" : "moderate",
    confidence: clamp01(0.55 + (worst.dur ? Math.min(worst.dur / 8, 0.38) : 0.35)),
    evidence: [
      worst.dh != null ? `Riposo diurno ~${worst.dh.toFixed(2)}\u202Fh` : null,
      worst.dur != null ? `durata inferita ~${worst.dur.toFixed(1)}\u202Fh` : null,
      worst.long ? ">90\u202Fmin aumenta interferenza sulla pressione omeostatica nel sonno notturno" : ""
    ].filter(Boolean),
    recommendation: {
      title: "Accorcia o anticipa ",
      action: worst.long ? "Mantieni sonnellini sotto ~25\u201335\u202Fmin; evita dopo le 15\u201316\u202Fh." : "Sposta prima il riposto o dimezza la durata per proteggere la notte.",
      reason: "Nap tardivi/lunghi tolgono quota di sonno ortodosso o anticipano cicli incompleti (euristica)."
    }
  };
}
function causeLargeCalorieDeficit(norm) {
  const b = numericOrNull(norm?.calorieBalanceApprox);
  if (b == null) return null;
  if (b >= -600) return null;
  const depth = Math.abs(b + 600);
  return {
    id: "large_calorie_deficit",
    label: "Deficit energetico ampio nella giornata",
    severity: depth >= 550 ? "high" : "moderate",
    confidence: clamp01(0.5 + Math.min(depth / 1500, 0.42)),
    evidence: [`Bilancio stimato giornaliero \u2248 ${Math.round(b)}\u202Fkcal (inferiore alla soglia \u2212600\u202Fkcal).`],
    recommendation: {
      title: "Recupero nutrizionale controllato",
      action: "In una seduta di giorno aumenta gradualmente carbohydrate leggeri in cena o snack serale stabile solo se compatibile meta.",
      reason: "Deficit molto larghi aumentano arousal corticale tardivo e possono aumentare sveglie correlate a fame relativi (euristica)."
    }
  };
}
function clamp01(x) {
  if (!Number.isFinite(x)) return 0;
  return Math.max(0, Math.min(1, x));
}
function analyzeSleepCoach(input) {
  const norm = input && typeof input === "object" ? input : {};
  const bedtime = clampDec(norm?._fallbackBedHour ?? norm?.sleep?.bedtimeDecimalResolved) ?? null;
  const wake = clampDec(norm?._wakeHintMerged ?? norm?.sleep?.wakeDecimalResolved ?? null);
  const sleepAssessment = buildSleepAssessment(norm);
  const rawCauses = [
    causeLateCaffeine(norm.incidents ?? [], bedtime, wake),
    causeLateWorkout(norm.incidents ?? [], bedtime, wake),
    causeLateHeavyMeal(norm.incidents ?? [], bedtime, wake),
    causeEveningAlcohol(norm.incidents ?? [], bedtime, wake),
    causeLateNap(norm.incidents ?? []),
    causeLargeCalorieDeficit(norm)
  ].filter(Boolean);
  const likelyCauses = sortCauses(rawCauses);
  const guidanceSteps = [];
  const seen = /* @__PURE__ */ new Set();
  for (const c of likelyCauses) {
    const rec = c.recommendation;
    if (!rec || typeof rec !== "object") continue;
    const key = `${String(rec.title ?? "")}\0${String(rec.action ?? "")}\0${String(rec.reason ?? "")}`;
    if (seen.has(key)) continue;
    seen.add(key);
    guidanceSteps.push({
      title: rec.title ?? "",
      action: rec.action ?? "",
      reason: rec.reason ?? ""
    });
  }
  const sleepsUnknown = norm?.sleep?.durationHoursResolved == null && (norm?.sleep?.qualityTierResolved ?? "unknown") === "unknown";
  let status = "sleep_ok";
  if (sleepsUnknown && likelyCauses.length === 0) {
    status = "insufficient_data";
  } else if (sleepAssessment.problematic || likelyCauses.some((x) => x.severity !== "low" && x.confidence >= 0.55)) {
    status = "sleep_disrupted";
  }
  let narrative = "";
  if (status === "sleep_ok") {
    narrative = "Nel complesso riposo e abitudini segnano una giornata coerente col recupero: continua sul binario degli orari stabili.";
  } else if (status === "insufficient_data") {
    narrative = "Serve almeno un\u2019indicazione di sonno (ore o giudizio sulla qualit\xE0) per valutare con precisione.";
  } else if (likelyCauses.length === 0) {
    narrative = "Il sonno appare delicato/non ottimale, ma dai log giornalieri non emergono comportamenti univoci.";
  } else {
    narrative = `Possibili fattori serali dai log (${likelyCauses.slice(0, 3).map((x) => x.label).join(", ")}): servono pi\xF9 giorni per conferma.`;
  }
  const avgConf = likelyCauses.length > 0 ? clamp01(arithmeticMean(likelyCauses.map((x) => x.confidence ?? 0))) : sleepsUnknown && status === "insufficient_data" ? null : 0.5;
  return {
    status,
    sleepAssessment,
    likelyCauses,
    guidanceSteps,
    confidence: avgConf == null ? null : sleepAssessment.problematic ? clamp01((avgConf + 0.6) / 2) : avgConf,
    narrative,
    debug: {
      incidentCount: (norm.incidents || []).length,
      bedtimeApproxUsed: bedtime,
      wakeApproxUsed: wake,
      timingsMode: numericOrNull(norm?.sleep?.bedtimeDecimalResolved) != null ? "sleep_entry_clock" : "fallback_or_reconstructed",
      hasTimingEvidence: likelyCauses.length > 0,
      sleepPrimitives: norm.sleep ?? {}
    }
  };
}
function arithmeticMean(arr) {
  if (!arr.length) return 0;
  let s = 0;
  for (let i = 0; i < arr.length; i += 1) s += arr[i];
  return s / arr.length;
}

// src/dev/testSleepCoach.js
var testCases = [
  {
    name: "caffeina + workout serale",
    log: [
      {
        type: "sleep",
        bedtimeApprox: 23.5,
        wakeHour: 5.5,
        hours: 6,
        quality: "scarsa"
      },
      {
        type: "food",
        /** `desc` con "coffee": il regex caffeina sul label con accenti può non matchare `\b` in tutti i motori */
        desc: "coffee",
        name: "caff\xE8",
        time: 17.5
      },
      {
        type: "workout",
        desc: "HIIT",
        time: 21,
        kcal: 400,
        duration: 40
      }
    ]
  },
  {
    name: "sonno buono, nessuna causa",
    log: [
      {
        type: "sleep",
        bedtimeApprox: 23,
        wakeHour: 7,
        hours: 8,
        quality: "buona"
      }
    ]
  },
  {
    name: "pasto pesante + alcol",
    log: [
      {
        type: "sleep",
        /** mezzanotte come 0 h (24 non è nel range clamp 0–24 esclusivo) */
        bedtimeApprox: 0,
        wakeHour: 6,
        hours: 6,
        quality: "scarsa"
      },
      {
        type: "food",
        name: "pizza",
        time: 22,
        kcal: 900
      },
      {
        type: "food",
        name: "vino",
        time: 22.5
      }
    ]
  }
];
function runTests() {
  console.log("=== SLEEP COACH TEST ===");
  testCases.forEach((test) => {
    const input = buildSleepCoachInputFromDailyLog(test.log);
    const result = analyzeSleepCoach(input);
    console.log(`
--- ${test.name} ---`);
    console.log("status:", result.status);
    console.log("cause:", result.likelyCauses.map((c) => c.id));
    console.log("confidence:", result.confidence);
    console.log("narrative:", result.narrative);
  });
}
runTests();
/*! Bundled license information:

react/cjs/react.production.min.js:
  (**
   * @license React
   * react.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react.development.js:
  (**
   * @license React
   * react.development.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
